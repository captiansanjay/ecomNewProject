package com.yash.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yash.model.User;
import com.yash.repository.RegistrationRepository;

@Service
public class RegistrationService {

	@Autowired
	private RegistrationRepository repo;

	public User saveUser(User user) {
		return repo.save(user);
	}

	public User fetchuserEmailid(String email) {
		return repo.findByEmailid(email);

	}

	public User findByEmailidAndPassword(String emailid, String password) {
		return repo.findByEmailidAndPassword(emailid, password);

	}

	

}
