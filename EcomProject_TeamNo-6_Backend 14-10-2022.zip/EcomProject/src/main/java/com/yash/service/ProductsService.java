package com.yash.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.model.Products;
import com.yash.repository.ProductsRepository;

@Service
public class ProductsService {

	@Autowired
	private ProductsRepository productsRepository;

	public List<Products> findAllProducts() {

		return productsRepository.findAll();

	}

	public List<Products> findallfashion(String str) {

		return productsRepository.findAll();
	}

	public List<Products> findByCatagoryType(String catagoryType) {

		return productsRepository.findByCatagoryType(catagoryType);
	}
}
