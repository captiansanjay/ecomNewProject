package com.yash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.yash.model.Products;
import com.yash.model.User;
import com.yash.service.ProductsService;
import com.yash.service.RegistrationService;

@RestController

@CrossOrigin(origins = "*")
public class RegistrationController {

	@Autowired
	private RegistrationService service;
	@Autowired
	private ProductsService prodservice;

	@PostMapping("/registeruser")
	@CrossOrigin(origins = "http://localhost:4200")
	public User registerUser(@RequestBody User user) throws Exception {
		String tempEmailid = user.getEmailid();
		if (tempEmailid != null && !" ".equals(tempEmailid)) {
			User use = service.fetchuserEmailid(tempEmailid);
			if (use != null) {
				throw new Exception("user with" + tempEmailid + "is already exit");
			}
		}
		User usobj = null;
		usobj = service.saveUser(user);
		return usobj;
	}

	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200")
	public User loginUser(@RequestBody User user) throws Exception {
		String tempEmil = user.getEmailid();
		String tempPassword = user.getPassword();
		User userobj = null;
		System.out.println(tempEmil + "  " + tempPassword);
		if (tempEmil != null && tempPassword != null) {
			userobj = service.findByEmailidAndPassword(tempEmil, tempPassword);

		}
		if (userobj.getEmailid().equals(tempEmil) && userobj.getPassword().equals(tempPassword))

			return user;
		return userobj;

	}

	@GetMapping("/findAllProd")
	// @CrossOrigin("*")
	private List<Products> findAllProducts() {

		return prodservice.findAllProducts();
	}

	@GetMapping("/findAllByCategory/{catagoryType}")
	List<Products> findAllProductsbycategory(@PathVariable String catagoryType) throws Exception {
		
		System.out.println(catagoryType);
		return prodservice.findByCatagoryType(catagoryType);
	}

}
