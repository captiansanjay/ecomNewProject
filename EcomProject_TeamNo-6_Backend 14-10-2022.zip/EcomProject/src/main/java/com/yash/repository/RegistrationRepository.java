package com.yash.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.yash.model.User;

@EnableJpaRepositories
public interface RegistrationRepository extends JpaRepository<User, Integer> {

	public User findByEmailid(String emailid);

	public User findByEmailidAndPassword(String emailid, String password);

	

	
}
