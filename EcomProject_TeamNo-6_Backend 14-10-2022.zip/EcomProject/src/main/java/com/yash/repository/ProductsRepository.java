package com.yash.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


import com.yash.model.Products;

@EnableJpaRepositories
public interface ProductsRepository extends JpaRepository<Products, String> {

	//@Query("SELECT p FROM Products p WHERE p.name LIKE :n")
	//List<Products> findByName(@Param("n") String name);
	

	List<Products> findByCatagoryType(String catagoryType);

}
