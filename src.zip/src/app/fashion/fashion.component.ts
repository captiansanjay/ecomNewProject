import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { CartService } from '../service/cart.service';

@Component({
  selector: 'app-fashion',
  templateUrl: './fashion.component.html',
  styleUrls: ['./fashion.component.css']
})
export class FashionComponent implements OnInit {
  public productlistfashion: any;
  public totalItem: number = 0;
  public myItem: any;
  constructor(private api: RegistrationService, private cartservice: CartService,private _route:Router ) { }

  ngOnInit(): void {
    if (sessionStorage.getItem('name') != null) {
      this.myItem = sessionStorage.getItem('name');
      this.api.getProductFashion().subscribe(res => {
        this.productlistfashion = res;
        this.productlistfashion.forEach((a: any) => {
          Object.assign(a, { quantity: 1, total: a.price })

        });
      })
    }
    else{
      this._route.navigate(['/login']);

    }
    this.cartservice.getProducts().subscribe(res => {
      this.totalItem = res.length;
    })
  }
  addtoCart(item: any) {
    this.cartservice.addtoCart(item);
  }
  logout() {
    console.log("logout");
    sessionStorage.removeItem('name');

  }

}
