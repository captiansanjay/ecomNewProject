export class User {
    id!:number;
    emailid!:string;
    password!: string;
    firstname!:string;
    lastname!:string;
    mobileNo!:string;
    gender!:string;

    constructor(){
     

    }
}
