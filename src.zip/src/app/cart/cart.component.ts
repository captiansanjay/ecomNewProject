import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../service/cart.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public product: any = [];
  public grandTotal!: number;
  public totalItem: number = 0;
  public myItem!: any;
  public myitem1: any;
  constructor(private cartservice: CartService,private _route:Router) { }


  title = "Google pay button";

  ngOnInit(): void {
    if (sessionStorage.getItem('name') != null) {
      this.myItem = sessionStorage.getItem('name');
      this.cartservice.getProducts().subscribe(
        res => {
          this.product = res;
          this.grandTotal = this.cartservice.getTotalprice();
          this.myitem1 = localStorage.setItem('grandtotal', JSON.stringify(this.grandTotal));
        }
      )
    }
    else {
      this._route.navigate(['/login']);

    }
    this.cartservice.getProducts().subscribe(res => {
      this.totalItem = res.length;
    })
  }
  addtoCart(item: any) {
    this.cartservice.addtoCart(item);
  }
  removeItem(item: any) {
    this.cartservice.removeCartitem(item);
  }
  emptycart() {
    this.cartservice.removeAllCart();
  }

  onLoadPaymentData(event: any) {
    console.log("load payment data", event.detail);
  }

  logout() {
    console.log("logout");
    sessionStorage.removeItem('name');

  }

}
