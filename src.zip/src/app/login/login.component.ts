import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user = new User();
  msg = '';
  constructor(private _service: RegistrationService, private _route: Router) { }
  ngOnInit(): void {
  }
  loginUser() {
    this._service.loginUserFromRemote(this.user).subscribe(
      data => {
        if (this.user.emailid != null) {
          sessionStorage.setItem('name', this.user.emailid)
        
        console.log("rsponce reciveed");
        this._route.navigate(['/loginsuccess'])
      }
      else{
        this._route.navigate([' '])
      }
      },
      error => {
        console.log("exception occuerd")
        this.msg = "Bad credentials!!!!!!!!";
      }
    );
  }
  gotoregistration() {
    this._route.navigate(['/registration'])
  }
}
