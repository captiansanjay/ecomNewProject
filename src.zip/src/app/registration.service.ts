import { Injectable } from '@angular/core';
import { User } from './user';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs'
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  constructor(private _http: HttpClient) { }
  //user login
  public loginUserFromRemote(user: User): Observable<any> {
    console.log(user);
    return this._http.post<any>('http://localhost:8080/login', user)
  }
  //register user
  public registerUserFromRemote(user: User): Observable<any> {
    return this._http.post<any>('http://localhost:8080/registeruser', user)
  }
  //get all products form db
  getProducts() {
    return this._http.get<any>("http://localhost:8080/findAllProd").pipe(map((res: any) => {
      return res;
    }))
  }
  //get all fashion catagory products form db
  getProductFashion() {
    return this._http.get<any>("http://localhost:8080/findAllByCategory/fashion").pipe(map((res: any) => {
      return res;
    }))
  }
  //get all electronics catagory products form db
  getProductElectronics() {
    return this._http.get<any>("http://localhost:8080/findAllByCategory/electronics").pipe(map((res: any) => {
      return res;
    }))
  }
  //get all jewelry catagory products form db
  getProductJewelry() {
    return this._http.get<any>("http://localhost:8080/findAllByCategory/Jewelry").pipe(map((res: any) => {
      return res;
    }))
  }
}
